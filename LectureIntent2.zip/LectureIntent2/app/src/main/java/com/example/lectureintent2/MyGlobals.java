package com.example.lectureintent2;

import android.app.Application;

public class MyGlobals extends Application {
    String editTextStr;
}
